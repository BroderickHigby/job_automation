# job_automation
Displaced workers in America due to Automation

## Data Sources
1. THE FUTURE OF EMPLOYMENT: HOW SUSCEPTIBLE ARE JOBS TO COMPUTERISATION?
https://www.oxfordmartin.ox.ac.uk/downloads/academic/The_Future_of_Employment.pdf

2. ONet Online
google the SOC code

Please check Github issues for latest updates

So for every state, we would have eac state that its int terms of probalbility instead of in terms of people.
Example: If we have a state that has 50 people and 50% of jobs are going to be automate, then we would say that
25 people would lose their jobs. We would put a red dot where the majority of people 

